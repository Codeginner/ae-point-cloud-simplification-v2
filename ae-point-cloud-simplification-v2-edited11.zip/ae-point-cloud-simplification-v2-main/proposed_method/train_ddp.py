"""
train_ddp.py — DistributedDataParallel training + evaluation script.

Lebih efisien dari DataParallel karena setiap GPU punya proses sendiri
(tidak ada GIL bottleneck, gradient sync lebih cepat).

Usage — single node, 2 GPU (Kaggle T4 x2):
    torchrun --nproc_per_node=2 proposed_method/train_ddp.py [args]

    atau:
    python -m torch.distributed.run --nproc_per_node=2 proposed_method/train_ddp.py [args]

Usage — test / eval only (1 proses, tidak perlu torchrun):
    python proposed_method/train_ddp.py --mode test --resume ./checkpoints/best.pth

Args penting:
    --mode        train | test          (default: train)
    --data_root   path ke folder data
    --resume      path ke checkpoint .pth
    --n_points    jumlah point per sampel
    --M           jumlah simplified points
    --batch_size  per GPU (total = batch_size × n_gpu)
"""

import os
import sys
import argparse
import logging
from pathlib import Path

import torch
import torch.nn as nn
import torch.optim as optim
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler

# Import dari package — support run sebagai script langsung maupun modul
if __package__:
    from .model  import PointCloudSimplifier
    from .train  import (PointCloudDataset, ModelNet40H5, build_dataset,
                         DATASET_CONFIG, SUPPORTED_DATASETS, _resolve_num_class)
else:
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from proposed_method.model import PointCloudSimplifier
    from proposed_method.train import (PointCloudDataset, ModelNet40H5, build_dataset,
                                       DATASET_CONFIG, SUPPORTED_DATASETS, _resolve_num_class)


# ---------------------------------------------------------------------------
# PointNet frozen — task network untuk task-aware training
# ---------------------------------------------------------------------------

class STN(nn.Module):
    """Spatial Transformer Network — T-Net dari PointNet original."""
    def __init__(self, k: int = 3) -> None:
        super().__init__()
        self.k = k
        self.conv = nn.Sequential(
            nn.Conv1d(k, 64, 1), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 128, 1), nn.BatchNorm1d(128), nn.ReLU(),
            nn.Conv1d(128, 1024, 1), nn.BatchNorm1d(1024), nn.ReLU(),
        )
        self.fc = nn.Sequential(
            nn.Linear(1024, 512), nn.BatchNorm1d(512), nn.ReLU(),
            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(),
            nn.Linear(256, k * k),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B = x.size(0)
        x = self.conv(x).max(dim=-1).values
        x = self.fc(x).view(B, self.k, self.k)
        x += torch.eye(self.k, device=x.device).unsqueeze(0)
        return x


class PointNetCls(nn.Module):
    """Full PointNet classifier dengan T-Net (STN) — identik dengan checkpoint."""
    def __init__(self, num_class: int = 40) -> None:
        super().__init__()
        self.tnet3  = STN(k=3)
        self.tnet64 = STN(k=64)
        self.conv1 = nn.Sequential(nn.Conv1d(3, 64, 1),   nn.BatchNorm1d(64),   nn.ReLU())
        self.conv2 = nn.Sequential(nn.Conv1d(64, 64, 1),  nn.BatchNorm1d(64),   nn.ReLU())
        self.conv3 = nn.Sequential(nn.Conv1d(64, 128, 1), nn.BatchNorm1d(128),  nn.ReLU())
        self.conv4 = nn.Sequential(nn.Conv1d(128, 1024, 1), nn.BatchNorm1d(1024), nn.ReLU())
        self.fc = nn.Sequential(
            nn.Linear(1024, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(512, 256),  nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(256, num_class),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (B, N, 3) → logits: (B, num_class)"""
        x = x.permute(0, 2, 1)              # (B, 3, N)
        # Input transform
        t3 = self.tnet3(x)                  # (B, 3, 3)
        x  = torch.bmm(t3, x)              # (B, 3, N)
        x  = self.conv2(self.conv1(x))      # (B, 64, N)
        # Feature transform
        t64 = self.tnet64(x)               # (B, 64, 64)
        x   = torch.bmm(t64, x)            # (B, 64, N)
        x   = self.conv4(self.conv3(x))    # (B, 1024, N)
        x   = x.max(dim=-1).values         # (B, 1024)
        return self.fc(x)                  # (B, num_class)


def load_pointnet_frozen(ckpt_path: str, num_class: int, device: torch.device) -> PointNetCls:
    """Load PointNet dan freeze semua parameternya."""
    pn = PointNetCls(num_class=num_class).to(device)
    ckpt = torch.load(ckpt_path, map_location=device)
    state = ckpt.get("model", ckpt.get("model_state_dict", ckpt))
    pn.load_state_dict(state)
    pn.eval()
    for p in pn.parameters():
        p.requires_grad_(False)
    return pn


# ---------------------------------------------------------------------------
# Logging — hanya rank 0 yang print supaya tidak berantakan
# ---------------------------------------------------------------------------

def setup_logger(rank: int) -> logging.Logger:
    logger = logging.getLogger("train_ddp")
    if rank == 0:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [rank0] %(message)s",
            datefmt="%H:%M:%S",
        )
    else:
        logging.disable(logging.CRITICAL)   # silence non-rank-0
    return logger


# ---------------------------------------------------------------------------
# DDP setup / cleanup
# ---------------------------------------------------------------------------

def setup_ddp(rank: int, world_size: int) -> None:
    """Inisialisasi process group DDP."""
    os.environ.setdefault("MASTER_ADDR", "localhost")
    os.environ.setdefault("MASTER_PORT", "12355")
    dist.init_process_group(
        backend="nccl",          # nccl = best untuk GPU-GPU communication
        rank=rank,
        world_size=world_size,
    )
    torch.cuda.set_device(rank)


def cleanup_ddp() -> None:
    dist.destroy_process_group()


# ---------------------------------------------------------------------------
# Build DataLoader dengan DistributedSampler
# ---------------------------------------------------------------------------

def build_loaders(args: argparse.Namespace, rank: int, world_size: int):
    train_ds = build_dataset(
        data_root=args.data_root, mode="train",
        n_points=args.n_points,   augment=True,
        dataset=args.dataset,     data_format=args.data_format,
    )
    val_ds = build_dataset(
        data_root=args.data_root, mode="test",
        n_points=args.n_points,   augment=False,
        dataset=args.dataset,     data_format=args.data_format,
    )

    # DistributedSampler: tiap GPU hanya lihat subset data-nya sendiri
    train_sampler = DistributedSampler(
        train_ds, num_replicas=world_size, rank=rank, shuffle=True, drop_last=True,
    )
    val_sampler = DistributedSampler(
        val_ds, num_replicas=world_size, rank=rank, shuffle=False, drop_last=False,
    )

    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,      # per GPU
        sampler=train_sampler,
        num_workers=args.num_workers,
        pin_memory=True,
        persistent_workers=args.num_workers > 0,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        sampler=val_sampler,
        num_workers=args.num_workers,
        pin_memory=True,
        persistent_workers=args.num_workers > 0,
    )

    return train_loader, val_loader, train_sampler


# ---------------------------------------------------------------------------
# Reduce loss tensors across all ranks → rata-rata global
# ---------------------------------------------------------------------------

def reduce_dict(loss_dict: dict, world_size: int) -> dict:
    """All-reduce loss values dari semua GPU, return rata-rata."""
    reduced = {}
    for k, v in loss_dict.items():
        t = v.clone() if isinstance(v, torch.Tensor) else torch.tensor(v)
        dist.all_reduce(t, op=dist.ReduceOp.SUM)
        reduced[k] = (t / world_size).item()
    return reduced


def train_one_epoch(
    model: DDP,
    loader: DataLoader,
    sampler: DistributedSampler,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    epoch: int,
    total_epochs: int,
    rank: int,
    world_size: int,
    logger: logging.Logger,
    pointnet: "PointNetCls | None" = None,
    lambda_task: float = 1.0,
) -> dict[str, float]:

    from tqdm import tqdm

    model.train()
    if pointnet is not None:
        pointnet.eval()   # selalu frozen
    sampler.set_epoch(epoch)

    totals = {
        "total": 0.0,
        "chamfer": 0.0,
        "normal": 0.0,
        "nc": 0.0,
        "score": 0.0,
        "cls": 0.0,
        "task": 0.0,     # PointNet task-aware loss
    }
    # ONE EPOCH = ONE LINE
    pbar = tqdm(
        total=len(loader),
        desc=f"Train Epoch {epoch+1}/{total_epochs}",
        disable=(rank != 0),
        dynamic_ncols=True,
        position=0,
        leave=True,
    )

    for step, (P, labels) in enumerate(loader):

        P = P.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        optimizer.zero_grad()

        out = model(P, labels, compute_loss=True)
        loss = out["loss"]

        # ── Task-aware loss: gradient langsung dari PointNet frozen ────
        if pointnet is not None:
            P_s    = out["P_simplified"]                       # (B, M, 3)
            logits = pointnet(P_s)                             # (B, num_class)
            L_task = nn.functional.cross_entropy(logits, labels)
            loss["task"]  = L_task
            loss["total"] = loss["total"] + lambda_task * L_task
        else:
            loss["task"] = torch.tensor(0.0, device=device)

        # Guard: skip batch if loss is NaN/Inf (e.g. degenerate point cloud)
        if not torch.isfinite(loss["total"]):
            if rank == 0:
                logger.warning(f"[Epoch {epoch+1} step {step}] NaN/Inf loss detected — skipping batch")
            optimizer.zero_grad()
            continue

        loss["total"].backward()

        # Check for NaN in gradients before stepping
        has_nan_grad = any(
            p.grad is not None and not torch.isfinite(p.grad).all()
            for p in model.parameters()
        )
        if has_nan_grad:
            if rank == 0:
                logger.warning(f"[Epoch {epoch+1} step {step}] NaN gradient detected — skipping step")
            optimizer.zero_grad()
            continue

        nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

        optimizer.step()

        for k, v in loss.items():
            totals[k] += v.item()

        if rank == 0:

            avg_total = totals["total"] / (step + 1)
            avg_cd    = totals["chamfer"] / (step + 1)
            avg_n     = totals["normal"] / (step + 1)
            avg_nc    = totals["nc"] / (step + 1)

            pbar.set_postfix({
                "loss": f"{avg_total:.4f}",
                "cd":   f"{avg_cd:.4f}",
                "n":    f"{avg_n:.4f}",
                "nc":   f"{avg_nc:.4f}",
                "task": f"{totals['task'] / (step + 1):.4f}",
            })

            pbar.update(1)

    pbar.close()

    n = len(loader)

    return {k: v / n for k, v in totals.items()}


# ---------------------------------------------------------------------------
# Validation step
# ---------------------------------------------------------------------------

@torch.no_grad()
def validate(
    model:      DDP,
    loader:     DataLoader,
    device:     torch.device,
    world_size: int,
    rank:       int,
    epoch:      int,
    total_epochs: int,
    pointnet: "PointNetCls | None" = None,
    lambda_task: float = 1.0,
) -> dict[str, float]:

    from tqdm import tqdm

    model.eval()

    totals = {
        "total": 0.0,
        "chamfer": 0.0,
        "normal": 0.0,
        "nc": 0.0,
        "score": 0.0,
        "cd_simplified": 0.0,
        "cls": 0.0,
        "task": 0.0,
        "task_correct": 0.0,
        "task_total":   0.0,
    }

    pbar = tqdm(
        total=len(loader),
        desc=f"Val Epoch {epoch+1}/{total_epochs}",
        disable=(rank != 0),
        dynamic_ncols=True,
        position=0,
        leave=True,
    )

    for step, (P, labels) in enumerate(loader):

        P = P.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        out = model(P, labels, compute_loss=True)
        loss = out["loss"]

        # ── Task-aware validation (PointNet OA) ───────────────────────
        P_s = out["P_simplified"]   # (B, M, 3)
        if pointnet is not None:
            logits = pointnet(P_s)
            L_task = nn.functional.cross_entropy(logits, labels)
            loss["task"]  = L_task
            loss["total"] = loss["total"] + lambda_task * L_task
            totals["task_correct"] += (logits.argmax(1) == labels).sum().item()
            totals["task_total"]   += labels.size(0)
        else:
            loss["task"] = torch.tensor(0.0, device=device)

        for k, v in loss.items():
            totals[k] += v.item()

        # CD(P_simplified, P_input)
        diff  = P_s.unsqueeze(2) - P.unsqueeze(1)
        d2    = (diff ** 2).sum(-1)
        s2p   = d2.min(dim=2).values.mean()
        diff2 = P.unsqueeze(2) - P_s.unsqueeze(1)
        d2b   = (diff2 ** 2).sum(-1)
        p2s   = d2b.min(dim=2).values.mean()
        totals["cd_simplified"] += (s2p + p2s).item()

        if rank == 0:
            avg_total   = totals["total"]  / (step + 1)
            avg_cd_simp = totals["cd_simplified"] / (step + 1)
            task_oa     = (totals["task_correct"] / totals["task_total"] * 100
                           if totals["task_total"] > 0 else 0.0)
            pbar.set_postfix({
                "loss":    f"{avg_total:.4f}",
                "cd_simp": f"{avg_cd_simp:.4f}",
                "pn_oa":   f"{task_oa:.1f}%",
            })
            pbar.update(1)

    pbar.close()

    n = len(loader)
    local_avgs = {
        k: torch.tensor(v / n if k not in ("task_correct", "task_total") else v,
                        device=device)
        for k, v in totals.items()
    }
    reduced = reduce_dict(local_avgs, world_size)

    # Hitung OA dari accumulated correct/total (bukan rata-rata per batch)
    if totals["task_total"] > 0:
        reduced["pointnet_oa"] = totals["task_correct"] / totals["task_total"] * 100
    else:
        reduced["pointnet_oa"] = 0.0

    return reduced


# ---------------------------------------------------------------------------
# Test / Evaluation only
# ---------------------------------------------------------------------------

@torch.no_grad()
def run_test(args: argparse.Namespace) -> None:
    """Jalankan evaluasi tanpa DDP (single process)."""
    from tqdm import tqdm

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[test] device={device}")

    val_ds = PointCloudDataset(
        data_root=args.data_root, mode='test',
        n_points=args.n_points,   augment=False,
        dataset=args.dataset,
    )
    val_loader = DataLoader(
        val_ds, batch_size=args.batch_size,
        shuffle=False, num_workers=args.num_workers, pin_memory=True,
    )

    model = PointCloudSimplifier(M=args.M, k=args.k, alpha=args.alpha, threshold=args.threshold, lambda_1=args.lambda_1, lambda_2=args.lambda_2, lambda_3=args.lambda_3, lambda_4=args.lambda_4, num_class=args.num_class, lambda_cls=args.lambda_cls).to(device)

    assert args.resume is not None, "Test mode butuh --resume path/ke/checkpoint.pth"
    ckpt  = torch.load(args.resume, map_location=device)
    state = ckpt["model"] if "model" in ckpt else ckpt
    model.load_state_dict(state)
    print(f"[test] Loaded checkpoint: {args.resume}")

    model.eval()
    totals = {"total": 0.0, "chamfer": 0.0, "normal": 0.0, "nc": 0.0, "score": 0.0, "cls": 0.0}

    pbar = tqdm(val_loader, desc="[Test]", dynamic_ncols=True)
    for step, (P, labels) in enumerate(pbar):          # BUG FIX: unpack labels (sebelumnya di-ignore)
        P      = P.to(device)
        labels = labels.to(device)                      # BUG FIX: kirim labels ke model
        out    = model(P, labels=labels, compute_loss=True)
        loss = out["loss"]
        for k, v in loss.items():
            totals[k] += v.item()
        avg = totals["total"] / (step + 1)
        pbar.set_postfix({"loss": f"{avg:.4f}"})

    pbar.close()

    n = len(val_loader)
    print("\n" + "=" * 40)
    print("TEST RESULTS")
    print("=" * 40)
    for k, v in totals.items():
        print(f"  {k:10s}: {v / n:.6f}")
    print("=" * 40)


# ---------------------------------------------------------------------------
# Main DDP worker (dipanggil oleh torchrun per GPU)
# ---------------------------------------------------------------------------

def ddp_worker(rank: int, world_size: int, args: argparse.Namespace) -> None:
    from tqdm import tqdm

    setup_ddp(rank, world_size)
    device = torch.device(f"cuda:{rank}")
    logger = setup_logger(rank)

    if rank == 0:
        logger.info(f"DDP world_size={world_size}  batch_size per GPU={args.batch_size}"
                    f"  total effective batch={args.batch_size * world_size}")

    # ── Data ──────────────────────────────────────────────────────────
    train_loader, val_loader, train_sampler = build_loaders(args, rank, world_size)

    if rank == 0:
        logger.info(f"Train: {len(train_loader.dataset)} samples | "
                    f"Val: {len(val_loader.dataset)} samples")

    # ── PointNet frozen (task-aware training) ─────────────────────────
    pointnet = None
    if args.pointnet_ckpt is not None:
        pointnet = load_pointnet_frozen(args.pointnet_ckpt, args.num_class, device)
        if rank == 0:
            logger.info(f"PointNet frozen loaded: {args.pointnet_ckpt}  "
                        f"lambda_task={args.lambda_task}")

    # ── Model ─────────────────────────────────────────────────────────
    model = PointCloudSimplifier(M=args.M, k=args.k, alpha=args.alpha, threshold=args.threshold, lambda_1=args.lambda_1, lambda_2=args.lambda_2, lambda_3=args.lambda_3, lambda_4=args.lambda_4, num_class=args.num_class, lambda_cls=args.lambda_cls).to(device)
    model = nn.SyncBatchNorm.convert_sync_batchnorm(model)
    model = DDP(model, device_ids=[rank], output_device=rank, find_unused_parameters=False)

    optimizer = optim.AdamW(
        model.parameters(),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )

    # Match APES schedule:
    # - Linear warmup epoch 0→5  (lr: 1e-4*1e-4 → 1e-4)
    # - CosineAnnealingLR epoch 5→100  (eta_min=1e-6)
    warmup_epochs  = 5
    cosine_epochs  = args.epochs - warmup_epochs

    warmup_scheduler = optim.lr_scheduler.LinearLR(
        optimizer,
        start_factor=1e-4,   # start_lr = 1e-4 * 1e-4 = 1e-8
        end_factor=1.0,      # end_lr   = 1e-4
        total_iters=warmup_epochs,
    )
    cosine_scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=cosine_epochs,
        eta_min=1e-6,
    )
    scheduler = optim.lr_scheduler.SequentialLR(
        optimizer,
        schedulers=[warmup_scheduler, cosine_scheduler],
        milestones=[warmup_epochs],
    )

    start_epoch   = 0
    best_val_loss = float("inf")

    # ── Resume ────────────────────────────────────────────────────────
    if args.resume is not None:
        map_loc = {"cuda:0": f"cuda:{rank}"}
        ckpt    = torch.load(args.resume, map_location=map_loc)
        model.module.load_state_dict(ckpt["model"])
        optimizer.load_state_dict(ckpt["optimizer"])
        scheduler.load_state_dict(ckpt["scheduler"])
        start_epoch   = ckpt["epoch"] + 1
        best_val_loss = ckpt.get("best_val_loss", float("inf"))
        if rank == 0:
            logger.info(f"Resumed dari epoch {start_epoch}")

    ckpt_dir = Path(args.checkpoint)
    if rank == 0:
        ckpt_dir.mkdir(parents=True, exist_ok=True)

    # ── Epoch progress bar (rank 0 only) ──────────────────────────────
    epoch_range = range(start_epoch, args.epochs)
    epoch_pbar  = tqdm(
        epoch_range,
        desc="Training",
        disable=(rank != 0),
        dynamic_ncols=True,
        unit="epoch",
    )

    # ── Training loop ─────────────────────────────────────────────────
    for epoch in epoch_pbar:
        train_losses = train_one_epoch(
            model, train_loader, train_sampler,
            optimizer, device, epoch, args.epochs, rank, world_size, logger,
            pointnet=pointnet, lambda_task=args.lambda_task,
        )
        val_losses = validate(
            model, val_loader, device, world_size, rank, epoch, args.epochs,
            pointnet=pointnet, lambda_task=args.lambda_task,
        )
        '''
        if rank == 0 and epoch % 10 == 0:
            from proposed_method.visualize import visualize_point_clouds
            
            model.eval()
            
            batch = next(iter(val_loader))
            
            P, _ = batch
            P = P.to(device)

            with torch.no_grad():
                out = model(P, compute_loss=False)

            original   = P[0]
            simplified = out["P_simplified"][0]

            reconstructed = None

            if "P_recon" in out:
                reconstructed = out["P_recon"][0]

            visualize_point_clouds(
                original=original,
                simplified=simplified,
                reconstructed=reconstructed,
                save_path=f"./visualizations/epoch_{epoch+1}.png",
            )
        '''
        scheduler.step()
        
        if rank == 0:
            lr_now = scheduler.get_last_lr()[0]

            # Update outer epoch bar
            epoch_pbar.set_postfix({
                "train": f"{train_losses['total']:.4f}",
                "val":   f"{val_losses['total']:.4f}",
                "lr":    f"{lr_now:.1e}",
                "best":  f"{best_val_loss:.4f}",
            })

            logger.info(
                f"[Epoch {epoch+1}/{args.epochs}]  "
                f"train={train_losses['total']:.4f}  "
                f"val={val_losses['total']:.4f}  "
                f"cd_rec={val_losses['chamfer']:.4f}  "
                f"cls={val_losses['cls']:.4f}  "
                f"cd_simp={val_losses['cd_simplified']:.4f}  "
                f"n={val_losses['normal']:.4f}  "
                f"nc={val_losses['nc']:.4f}  "
                f"lr={lr_now:.2e}"
            )

            # Save checkpoint
            state_dict = model.module.state_dict()

            pn_oa = val_losses.get("pointnet_oa", 0.0)
            epoch_pbar.set_postfix({
                "train": f"{train_losses['total']:.4f}",
                "val":   f"{val_losses['total']:.4f}",
                "pn_oa": f"{pn_oa:.1f}%",
                "lr":    f"{lr_now:.1e}",
            })

            logger.info(
                f"[Epoch {epoch+1}/{args.epochs}]  "
                f"train={train_losses['total']:.4f}  "
                f"val={val_losses['total']:.4f}  "
                f"cd_simp={val_losses['cd_simplified']:.4f}  "
                f"n={val_losses['normal']:.4f}  "
                f"nc={val_losses['nc']:.4f}  "
                f"pn_oa={pn_oa:.2f}%  "
                f"lr={lr_now:.2e}"
            )

            torch.save({
                "epoch":         epoch,
                "model":         state_dict,
                "optimizer":     optimizer.state_dict(),
                "scheduler":     scheduler.state_dict(),
                "val_loss":      val_losses,
                "best_val_loss": best_val_loss,
                "pointnet_oa":   pn_oa,
                "args":          vars(args),
            }, ckpt_dir / "latest.pth")

            # Best model: pakai PointNet OA kalau ada, else val loss
            if pointnet is not None:
                if pn_oa > best_val_loss:
                    best_val_loss = pn_oa
                    torch.save(state_dict, ckpt_dir / "best.pth")
                    logger.info(f"  ★ New best PointNet OA: {best_val_loss:.2f}%")
            else:
                if val_losses["total"] < best_val_loss:
                    best_val_loss = val_losses["total"]
                    torch.save(state_dict, ckpt_dir / "best.pth")
                    logger.info(f"  ★ New best val loss: {best_val_loss:.4f}")

        dist.barrier()

    if rank == 0:
        epoch_pbar.close()

    cleanup_ddp()


# ---------------------------------------------------------------------------
# Argparse
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="DDP Training — PointCloudSimplifier",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # ── Mode ──────────────────────────────────────────────────────────
    parser.add_argument("--mode", type=str, default="train",
                        choices=["train", "test"],
                        help="'train' untuk DDP training, 'test' untuk evaluasi single-GPU")

    # ── Dataset ───────────────────────────────────────────────────────
    dataset_grp = parser.add_argument_group("Dataset")
    dataset_grp.add_argument(
        "--dataset", type=str, default="modelnet40",
        choices=SUPPORTED_DATASETS,
        help=(
            "Dataset yang digunakan. "
            "'modelnet10' = 10 kelas, 'modelnet40' = 40 kelas. "
            "num_class di-set otomatis kecuali --num_class di-override."
        ),
    )
    dataset_grp.add_argument(
        "--data_format", type=str, default="npy",
        choices=["npy", "hdf5"],
        help=(
            "'npy'  = format repo ini (data/modelnet40/pcd/). "
            "'hdf5' = format official APES/SampleNet (modelnet40_ply_hdf5_2048/). "
            "HDF5 hanya tersedia untuk modelnet40."
        ),
    )
    dataset_grp.add_argument(
        "--data_root", type=str, default="./data",
        help="Root folder data. Untuk --data_format hdf5, arahkan langsung ke "
             "modelnet40_ply_hdf5_2048/.",
    )

    # ── Model ─────────────────────────────────────────────────────────
    model_grp = parser.add_argument_group("Model")
    model_grp.add_argument("--n_points",  type=int,   default=1024)
    model_grp.add_argument("--M",         type=int,   default=512,
                           help="Jumlah simplified output points")
    model_grp.add_argument(
        "--num_class", type=int, default=None,
        help=(
            "Override jumlah kelas. Jika tidak di-set, otomatis mengikuti --dataset "
            "(modelnet10→10, modelnet40→40)."
        ),
    )
    model_grp.add_argument("--k",         type=int,   default=20)
    model_grp.add_argument("--alpha",     type=float, default=0.7,
                           help="Contour fraction in selector")
    model_grp.add_argument("--threshold", type=float, default=0.5,
                           help="NC threshold contour vs flat")

    # ── Training ──────────────────────────────────────────────────────
    train_grp = parser.add_argument_group("Training")
    train_grp.add_argument("--epochs",       type=int,   default=200)
    train_grp.add_argument("--batch_size",   type=int,   default=16,
                           help="Batch size PER GPU")
    train_grp.add_argument("--lr",           type=float, default=1e-4)
    train_grp.add_argument("--weight_decay", type=float, default=1e-4)
    train_grp.add_argument("--num_workers",  type=int,   default=4)
    train_grp.add_argument("--checkpoint",   type=str,   default="./checkpoints")
    train_grp.add_argument("--resume",       type=str,   default=None)

    # ── Task-aware training (PointNet frozen) ─────────────────────────
    task_grp = parser.add_argument_group("Task-aware training")
    task_grp.add_argument(
        "--pointnet_ckpt", type=str, default=None,
        help=(
            "Path ke pretrained PointNet checkpoint. "
            "Jika di-set, simplifier ditraining dengan gradient langsung dari "
            "PointNet frozen — ini yang paling efektif untuk naikkan OA eval."
        ),
    )
    task_grp.add_argument(
        "--lambda_task", type=float, default=1.0,
        help="Weight untuk task-aware loss dari PointNet frozen.",
    )

    # ── Loss weights ──────────────────────────────────────────────────
    loss_grp = parser.add_argument_group("Loss weights")
    loss_grp.add_argument("--lambda_1",   type=float, default=1.0)
    loss_grp.add_argument("--lambda_2",   type=float, default=0.5)
    loss_grp.add_argument("--lambda_3",   type=float, default=0.3)
    loss_grp.add_argument("--lambda_4",   type=float, default=0.3,
                          help="Weight for score supervision loss")
    loss_grp.add_argument("--lambda_cls", type=float, default=0.5,
                          help="Weight for classification loss")

    return _resolve_num_class(parser.parse_args())


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    args = parse_args()

    if args.mode == "test":
        # Test mode: single process, tidak perlu torchrun
        run_test(args)

    else:
        # Train mode: torchrun inject RANK, LOCAL_RANK, WORLD_SIZE otomatis
        rank       = int(os.environ.get("RANK",       0))
        local_rank = int(os.environ.get("LOCAL_RANK", 0))
        world_size = int(os.environ.get("WORLD_SIZE", 1))

        # Kalau WORLD_SIZE == 1 (tidak di-launch via torchrun), warning dulu
        if world_size == 1 and torch.cuda.device_count() > 1:
            print(
                "[WARNING] Terdeteksi >1 GPU tapi WORLD_SIZE=1.\n"
                "Jalankan via torchrun biar DDP aktif:\n"
                f"  torchrun --nproc_per_node={torch.cuda.device_count()} "
                f"proposed_method/train_ddp.py [args]"
            )

        ddp_worker(rank, world_size, args)