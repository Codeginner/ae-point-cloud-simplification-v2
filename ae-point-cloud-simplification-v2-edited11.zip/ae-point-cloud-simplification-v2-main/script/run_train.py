from proposed_method.train import main
 
if __name__ == "__main__":
    main()